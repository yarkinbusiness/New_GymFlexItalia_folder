//
//  HomeViewModel.swift
//  Gym Flex Italia
//
//  ViewModel for the Home/Dashboard tab.
//  Reads from canonical data stores: MockDataStore.gyms, MockBookingStore.
//  Uses LocationService for nearby gyms calculation.
//

import Foundation
import CoreLocation
import Combine

/// ViewModel for the Home tab - uses canonical data stores only
@MainActor
final class HomeViewModel: ObservableObject {
    
    // MARK: - Published State
    
    /// Nearby gyms sorted by distance (top 3)
    @Published var nearbyGyms: [Gym] = []
    
    /// All bookings sorted by startTime desc
    @Published var recentBookings: [Booking] = []
    
    /// Most recent booking of any status
    @Published var lastBooking: Booking?
    
    /// Active booking (checkedIn or upcoming that hasn't ended)
    @Published var activeBooking: Booking?
    
    /// Loading state
    @Published var isLoading = false
    
    /// Error message if any
    @Published var errorMessage: String?
    
    /// Whether location permission is granted
    @Published var locationPermissionGranted = false
    
    // MARK: - Private State
    
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    
    init() {
        // Initial load
        load()
    }
    
    // MARK: - Load Data
    
    /// Load bookings from MockBookingStore and compute derived properties
    func load() {
        let bookingStore = MockBookingStore.shared
        
        // Get all bookings sorted by startTime descending
        let allBookings = bookingStore.allBookings()
        recentBookings = allBookings
        
        // Find most recent booking (of any status)
        lastBooking = allBookings.first
        
        // Find active booking (checkedIn or upcoming that hasn't ended)
        let now = Date()
        activeBooking = allBookings.first { booking in
            guard booking.status != .cancelled else { return false }
            
            // Session hasn't ended yet
            guard booking.endTime > now else { return false }
            
            // Either checked in or confirmed (upcoming)
            return booking.status == .checkedIn || booking.status == .confirmed
        }
        
        print("🏠 HomeViewModel.load: \(allBookings.count) bookings, lastBooking=\(lastBooking?.gymName ?? "nil"), activeBooking=\(activeBooking?.id ?? "nil")")
    }
    
    // MARK: - Nearby Gyms
    
    /// Refresh nearby gyms based on user location
    /// - Parameter userLocation: Current user location (nil if unavailable)
    func refreshNearbyGyms(userLocation: CLLocation?) {
        let allGyms = MockDataStore.shared.gyms
        
        if let location = userLocation {
            locationPermissionGranted = true
            
            // Sort by distance and take top 3
            let sorted = allGyms.sorted { gym1, gym2 in
                gym1.distance(from: location) < gym2.distance(from: location)
            }
            nearbyGyms = Array(sorted.prefix(3))
            
            print("🏠 HomeViewModel.refreshNearbyGyms: \(nearbyGyms.count) nearby gyms (location available)")
        } else {
            // No location - show first 3 gyms from catalog
            nearbyGyms = Array(allGyms.prefix(3))
            locationPermissionGranted = false
            
            print("🏠 HomeViewModel.refreshNearbyGyms: \(nearbyGyms.count) gyms (no location)")
        }
    }
    
    // MARK: - Formatting Helpers
    
    /// Summary of last booking for Quick Book section
    /// Returns: (gymName, relativeDate, priceString) or nil if no booking
    func lastBookingSummary() -> (gymName: String, relativeDate: String, priceString: String)? {
        guard let booking = lastBooking else { return nil }
        
        let gymName = booking.gymName ?? "Unknown Gym"
        let relativeDate = formatRelativeDate(booking.startTime)
        let priceString = formatPrice(booking)
        
        return (gymName, relativeDate, priceString)
    }
    
    /// Format a date as relative string ("Today", "Yesterday", "X days ago")
    private func formatRelativeDate(_ date: Date) -> String {
        let calendar = Calendar.current
        let now = Date()
        
        if calendar.isDateInToday(date) {
            return "Today"
        } else if calendar.isDateInYesterday(date) {
            return "Yesterday"
        } else {
            let components = calendar.dateComponents([.day], from: date, to: now)
            if let days = components.day, days > 0 {
                return "\(days) days ago"
            } else if let days = components.day, days < 0 {
                // Future date
                let futureDays = abs(days)
                if futureDays == 1 {
                    return "Tomorrow"
                } else {
                    return "In \(futureDays) days"
                }
            } else {
                return date.formatted(date: .abbreviated, time: .omitted)
            }
        }
    }
    
    /// Format booking price
    private func formatPrice(_ booking: Booking) -> String {
        // Use totalPrice from booking if available
        if booking.totalPrice > 0 {
            return String(format: "€%.2f", booking.totalPrice)
        }
        
        // Fallback: calculate from duration using PricingCalculator
        let gym = MockDataStore.shared.gymById(booking.gymId)
        let pricePerHour = gym?.pricePerHour ?? 2.0
        let totalCents = PricingCalculator.priceForBooking(durationMinutes: booking.duration, gymPricePerHour: pricePerHour)
        return PricingCalculator.formatCentsAsEUR(totalCents)
    }
    
    // MARK: - Distance Helper
    
    /// Calculate distance string for a gym
    func distanceString(for gym: Gym, from location: CLLocation?) -> String? {
        guard let location = location else { return nil }
        
        let distance = gym.distance(from: location)
        
        if distance < 1000 {
            return String(format: "%.0f m", distance)
        } else {
            return String(format: "%.1f km", distance / 1000)
        }
    }
    
    // MARK: - Recent Activity
    
    /// Get completed/past bookings for Recent Activity section
    func completedBookings() -> [Booking] {
        let now = Date()
        return recentBookings.filter { booking in
            // Past bookings (ended) or explicitly completed
            booking.endTime < now || booking.status == .completed
        }
    }
}
